﻿using Microsoft.EntityFrameworkCore;
using Project.Models;
namespace Wireless.Models
{
    public class Db : DbContext
    {
        public Db(DbContextOptions<Db>options) : base(options){}
        public DbSet<Product> Products { get; set; }
    }
}