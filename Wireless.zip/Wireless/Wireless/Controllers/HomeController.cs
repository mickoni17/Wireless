﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Project.Models;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Wireless.Models;

namespace Wireless.Controllers
{
    public class HomeController : Controller
    {
        private readonly Db db;
        public void LoadJson()
        {
            using (StreamReader file = System.IO.File.OpenText("input.json"))
            using (JsonTextReader reader = new JsonTextReader(file))
            {
                dynamic items = JToken.ReadFrom(reader);
                foreach(JObject obj in items){
                    Product prod = new Product()
                    {
                        Name = obj["name"].ToString(),
                        Manufacturer = obj["manufacturer"].ToString(),
                        Creator = obj["creator"].ToString(),
                        Cost = float.Parse(obj["cost"].ToString()),
                        Category = obj["category"].ToString(),
                        Description = obj["description"].ToString()
                    };
                    db.Products.Add(prod);
                    db.SaveChanges();
                }
            }
        }
        public IActionResult AddJson()
        {
            LoadJson();
            return View("Index", db.Products.ToList());
        }
        public HomeController(Db db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            return View(db.Products.ToList());
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Add()
        {
            return View();
        }
        public IActionResult Edit(int id)
        {
            return View(db.Products.Find(id));
        }
        [HttpPost]
        public IActionResult Save(int Id,string Name, string Description, string Manufacturer, string Creator, string Category, float Cost)
        {
            Product prodUpdt = db.Products.Find(Id);
            prodUpdt.Name = Name;
            prodUpdt.Description = Description;
            prodUpdt.Manufacturer = Manufacturer;
            prodUpdt.Creator = Creator;
            prodUpdt.Category = Category;
            prodUpdt.Cost = Cost;
            db.SaveChanges();
            return View("Index", db.Products.ToList());
        }
        [HttpPost]
        public IActionResult Create(string Name, string Description, string Manufacturer, string Creator, string Category, float Cost)
        {
            db.Products.Add(new Product{
                Name = Name,
                Manufacturer = Manufacturer,
                Creator = Creator,
                Cost = Cost,
                Category = Category,
                Description = Description
            });
            db.SaveChanges();
            return View("Index", db.Products.ToList());
        }
        public IActionResult Delete(int id)
        {
            Product custDel = db.Products.Find(id);
            db.Products.Remove(custDel);
            db.SaveChanges();
            return View("Index", db.Products.ToList());
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
